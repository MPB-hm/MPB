const base = {
    get() {
        return {
            url : "http://localhost:8080/springboot2izxq/",
            name: "springboot2izxq",
            // 退出到首页链接
            indexUrl: 'http://localhost:8080/springboot2izxq/front/dist/index.html'
        };
    },
    getProjectName(){
        return {
            projectName: "基于Spring Boot的中医学习服务管理系统"
        } 
    }
}
export default base
