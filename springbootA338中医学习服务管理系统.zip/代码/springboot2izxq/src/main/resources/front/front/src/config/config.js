export default {
    baseUrl: 'http://localhost:8080/springboot2izxq/',
    indexNav: [
        {
            name: '首页',
            url: '/index/home'
        },
        {
            name: '中医药知识',
            url: '/index/zhongyiyaozhishi'
        },
        {
            name: '课程信息',
            url: '/index/kechengxinxi'
        },
        {
            name: '论坛',
            url: '/index/forum'
        }, 
        {
            name: '中医知识',
            url: '/index/news'
        },
    ]
}
