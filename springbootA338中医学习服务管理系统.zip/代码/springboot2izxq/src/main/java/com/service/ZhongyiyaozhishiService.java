package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.ZhongyiyaozhishiEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.ZhongyiyaozhishiVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.ZhongyiyaozhishiView;


/**
 * 中医药知识
 *
 * @author 
 * @email 
 * @date 2023-03-10 19:47:15
 */
public interface ZhongyiyaozhishiService extends IService<ZhongyiyaozhishiEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<ZhongyiyaozhishiVO> selectListVO(Wrapper<ZhongyiyaozhishiEntity> wrapper);
   	
   	ZhongyiyaozhishiVO selectVO(@Param("ew") Wrapper<ZhongyiyaozhishiEntity> wrapper);
   	
   	List<ZhongyiyaozhishiView> selectListView(Wrapper<ZhongyiyaozhishiEntity> wrapper);
   	
   	ZhongyiyaozhishiView selectView(@Param("ew") Wrapper<ZhongyiyaozhishiEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<ZhongyiyaozhishiEntity> wrapper);
   	

}

