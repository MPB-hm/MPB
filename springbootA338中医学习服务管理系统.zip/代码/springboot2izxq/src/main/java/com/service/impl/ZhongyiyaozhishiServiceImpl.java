package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.ZhongyiyaozhishiDao;
import com.entity.ZhongyiyaozhishiEntity;
import com.service.ZhongyiyaozhishiService;
import com.entity.vo.ZhongyiyaozhishiVO;
import com.entity.view.ZhongyiyaozhishiView;

@Service("zhongyiyaozhishiService")
public class ZhongyiyaozhishiServiceImpl extends ServiceImpl<ZhongyiyaozhishiDao, ZhongyiyaozhishiEntity> implements ZhongyiyaozhishiService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<ZhongyiyaozhishiEntity> page = this.selectPage(
                new Query<ZhongyiyaozhishiEntity>(params).getPage(),
                new EntityWrapper<ZhongyiyaozhishiEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<ZhongyiyaozhishiEntity> wrapper) {
		  Page<ZhongyiyaozhishiView> page =new Query<ZhongyiyaozhishiView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<ZhongyiyaozhishiVO> selectListVO(Wrapper<ZhongyiyaozhishiEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public ZhongyiyaozhishiVO selectVO(Wrapper<ZhongyiyaozhishiEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<ZhongyiyaozhishiView> selectListView(Wrapper<ZhongyiyaozhishiEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public ZhongyiyaozhishiView selectView(Wrapper<ZhongyiyaozhishiEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
