package com.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.lang.reflect.InvocationTargetException;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.beanutils.BeanUtils;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.baomidou.mybatisplus.enums.IdType;


/**
 * 中医药知识
 * 数据库通用操作实体类（普通增删改查）
 * @author 
 * @email 
 * @date 2023-03-10 19:47:15
 */
@TableName("zhongyiyaozhishi")
public class ZhongyiyaozhishiEntity<T> implements Serializable {
	private static final long serialVersionUID = 1L;


	public ZhongyiyaozhishiEntity() {
		
	}
	
	public ZhongyiyaozhishiEntity(T t) {
		try {
			BeanUtils.copyProperties(this, t);
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * 主键id
	 */
	@TableId
	private Long id;
	/**
	 * 知识标题
	 */
					
	private String zhishibiaoti;
	
	/**
	 * 封面图片
	 */
					
	private String fengmiantupian;
	
	/**
	 * 身体部位
	 */
					
	private String shentibuwei;
	
	/**
	 * 发布时间
	 */
				
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd")
	@DateTimeFormat 		
	private Date fabushijian;
	
	/**
	 * 症状
	 */
					
	private String zhengzhuang;
	
	/**
	 * 治疗方法
	 */
					
	private String zhiliaofangfa;
	
	/**
	 * 诊断
	 */
					
	private String zhenduan;
	
	/**
	 * 预防
	 */
					
	private String yufang;
	
	
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat
	private Date addtime;

	public Date getAddtime() {
		return addtime;
	}
	public void setAddtime(Date addtime) {
		this.addtime = addtime;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * 设置：知识标题
	 */
	public void setZhishibiaoti(String zhishibiaoti) {
		this.zhishibiaoti = zhishibiaoti;
	}
	/**
	 * 获取：知识标题
	 */
	public String getZhishibiaoti() {
		return zhishibiaoti;
	}
	/**
	 * 设置：封面图片
	 */
	public void setFengmiantupian(String fengmiantupian) {
		this.fengmiantupian = fengmiantupian;
	}
	/**
	 * 获取：封面图片
	 */
	public String getFengmiantupian() {
		return fengmiantupian;
	}
	/**
	 * 设置：身体部位
	 */
	public void setShentibuwei(String shentibuwei) {
		this.shentibuwei = shentibuwei;
	}
	/**
	 * 获取：身体部位
	 */
	public String getShentibuwei() {
		return shentibuwei;
	}
	/**
	 * 设置：发布时间
	 */
	public void setFabushijian(Date fabushijian) {
		this.fabushijian = fabushijian;
	}
	/**
	 * 获取：发布时间
	 */
	public Date getFabushijian() {
		return fabushijian;
	}
	/**
	 * 设置：症状
	 */
	public void setZhengzhuang(String zhengzhuang) {
		this.zhengzhuang = zhengzhuang;
	}
	/**
	 * 获取：症状
	 */
	public String getZhengzhuang() {
		return zhengzhuang;
	}
	/**
	 * 设置：治疗方法
	 */
	public void setZhiliaofangfa(String zhiliaofangfa) {
		this.zhiliaofangfa = zhiliaofangfa;
	}
	/**
	 * 获取：治疗方法
	 */
	public String getZhiliaofangfa() {
		return zhiliaofangfa;
	}
	/**
	 * 设置：诊断
	 */
	public void setZhenduan(String zhenduan) {
		this.zhenduan = zhenduan;
	}
	/**
	 * 获取：诊断
	 */
	public String getZhenduan() {
		return zhenduan;
	}
	/**
	 * 设置：预防
	 */
	public void setYufang(String yufang) {
		this.yufang = yufang;
	}
	/**
	 * 获取：预防
	 */
	public String getYufang() {
		return yufang;
	}

}
