package com.entity.model;

import com.entity.ZhongyiyaozhishiEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
 

/**
 * 中医药知识
 * 接收传参的实体类  
 *（实际开发中配合移动端接口开发手动去掉些没用的字段， 后端一般用entity就够用了） 
 * 取自ModelAndView 的model名称
 * @author 
 * @email 
 * @date 2023-03-10 19:47:15
 */
public class ZhongyiyaozhishiModel  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 封面图片
	 */
	
	private String fengmiantupian;
		
	/**
	 * 身体部位
	 */
	
	private String shentibuwei;
		
	/**
	 * 发布时间
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date fabushijian;
		
	/**
	 * 症状
	 */
	
	private String zhengzhuang;
		
	/**
	 * 治疗方法
	 */
	
	private String zhiliaofangfa;
		
	/**
	 * 诊断
	 */
	
	private String zhenduan;
		
	/**
	 * 预防
	 */
	
	private String yufang;
				
	
	/**
	 * 设置：封面图片
	 */
	 
	public void setFengmiantupian(String fengmiantupian) {
		this.fengmiantupian = fengmiantupian;
	}
	
	/**
	 * 获取：封面图片
	 */
	public String getFengmiantupian() {
		return fengmiantupian;
	}
				
	
	/**
	 * 设置：身体部位
	 */
	 
	public void setShentibuwei(String shentibuwei) {
		this.shentibuwei = shentibuwei;
	}
	
	/**
	 * 获取：身体部位
	 */
	public String getShentibuwei() {
		return shentibuwei;
	}
				
	
	/**
	 * 设置：发布时间
	 */
	 
	public void setFabushijian(Date fabushijian) {
		this.fabushijian = fabushijian;
	}
	
	/**
	 * 获取：发布时间
	 */
	public Date getFabushijian() {
		return fabushijian;
	}
				
	
	/**
	 * 设置：症状
	 */
	 
	public void setZhengzhuang(String zhengzhuang) {
		this.zhengzhuang = zhengzhuang;
	}
	
	/**
	 * 获取：症状
	 */
	public String getZhengzhuang() {
		return zhengzhuang;
	}
				
	
	/**
	 * 设置：治疗方法
	 */
	 
	public void setZhiliaofangfa(String zhiliaofangfa) {
		this.zhiliaofangfa = zhiliaofangfa;
	}
	
	/**
	 * 获取：治疗方法
	 */
	public String getZhiliaofangfa() {
		return zhiliaofangfa;
	}
				
	
	/**
	 * 设置：诊断
	 */
	 
	public void setZhenduan(String zhenduan) {
		this.zhenduan = zhenduan;
	}
	
	/**
	 * 获取：诊断
	 */
	public String getZhenduan() {
		return zhenduan;
	}
				
	
	/**
	 * 设置：预防
	 */
	 
	public void setYufang(String yufang) {
		this.yufang = yufang;
	}
	
	/**
	 * 获取：预防
	 */
	public String getYufang() {
		return yufang;
	}
			
}
