package com.dao;

import com.entity.ZhongyiyaozhishiEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.ZhongyiyaozhishiVO;
import com.entity.view.ZhongyiyaozhishiView;


/**
 * 中医药知识
 * 
 * @author 
 * @email 
 * @date 2023-03-10 19:47:15
 */
public interface ZhongyiyaozhishiDao extends BaseMapper<ZhongyiyaozhishiEntity> {
	
	List<ZhongyiyaozhishiVO> selectListVO(@Param("ew") Wrapper<ZhongyiyaozhishiEntity> wrapper);
	
	ZhongyiyaozhishiVO selectVO(@Param("ew") Wrapper<ZhongyiyaozhishiEntity> wrapper);
	
	List<ZhongyiyaozhishiView> selectListView(@Param("ew") Wrapper<ZhongyiyaozhishiEntity> wrapper);

	List<ZhongyiyaozhishiView> selectListView(Pagination page,@Param("ew") Wrapper<ZhongyiyaozhishiEntity> wrapper);
	
	ZhongyiyaozhishiView selectView(@Param("ew") Wrapper<ZhongyiyaozhishiEntity> wrapper);
	

}
